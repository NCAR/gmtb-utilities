ncl script to plot skewt-logp 
input: four sounding data
output: skewt-logp

main program:
skewt_plot.ncl

function called:
skewt_func1.ncl  
skewt_func.ncl 

email:Linlin.Pan@noaa.gov for any questions.
